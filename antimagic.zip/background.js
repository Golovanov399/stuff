chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		if (request.contentScriptQuery == "fixColors") {
			// https://gist.github.com/Golovanov399/9e4b23c4f6468aa02a1e36b89bdea291
			fetch("https://gist.github.com/Golovanov399/9e4b23c4f6468aa02a1e36b89bdea291/raw/gistfile1.txt")
				.then(response => response.text())
				.then(text => sendResponse(text))
			return true;
		}
	}
);
